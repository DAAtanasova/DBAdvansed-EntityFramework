﻿namespace P01_StudentSystem
{
    public class Configuration
    {
        public const string connectionString = "Server=NW9440\\SQLEXPRESS;Database=StudentSystem;Integrated Security = true";
    }
}
