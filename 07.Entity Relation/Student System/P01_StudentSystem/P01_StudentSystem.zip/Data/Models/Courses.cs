﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data.Models
{
    public class Courses
    {
        public int CourseId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public decimal Price { get; set; }

        public ICollection<StudentCourses> StudentsCourse { get; set; }
        public ICollection<Resources> Resources { get; set; }
        public ICollection<HomeworkSubmissions> HomeworkSubmissions { get; set; }

    }
}
